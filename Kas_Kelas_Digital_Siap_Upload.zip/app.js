const API="ISI_URL_WEB_APP";

function load(){
fetch(`${API}?action=getTransactions`)
.then(r=>r.json()).then(d=>{
 let saldo=0;
 data.innerHTML="";
 d.data.forEach(t=>{
  saldo+=t.jenis==="Pemasukan"?t.jumlah:-t.jumlah;
  data.innerHTML+=`
  <tr>
   <td>${t.tanggal}</td>
   <td>${t.jenis}</td>
   <td>${t.jumlah}</td>
   <td>${t.siswa_id}</td>
   <td><button class="btn btn-sm btn-danger" onclick="hapus('${t.id}')">Hapus</button></td>
  </tr>`;
 });
 document.getElementById("saldo").innerText="Saldo: Rp "+saldo;
});
}

function tambah(){
fetch(API,{method:"POST",
body:new URLSearchParams({
 action:"addTransaction",
 tanggal:tanggal.value,
 jenis:jenis.value,
 jumlah:jumlah.value,
 siswa_id:siswa.value,
 keterangan:ket.value
})}).then(()=>load());
}

function hapus(id){
fetch(API,{method:"POST",
body:new URLSearchParams({action:"deleteTransaction",id})
}).then(()=>load());
}

function exportPDF(){
fetch(`${API}?action=exportPDF`)
.then(r=>r.json())
.then(d=>window.open(d.url));
}

load();